/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite Zimlets
 * Copyright (C) 2005, 2006, 2007, 2008, 2009, 2010 Zimbra, Inc.
 * 
 * The contents of this file are subject to the Zimbra Public License
 * Version 1.3 ("License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.zimbra.com/license.
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * ***** END LICENSE BLOCK *****
 */

/**
 * Defines the Zimlet handler class.
 *   
 */
function com_tetris_HandlerObject() {
}

/**
 * Makes the Zimlet class a subclass of ZmZimletBase.
 *
 */
com_tetris_HandlerObject.prototype = new ZmZimletBase();
com_tetris_HandlerObject.prototype.constructor = com_tetris_HandlerObject;

/**
 * This method gets called by the Zimlet framework when the zimlet loads.
 *  
 */
com_tetris_HandlerObject.prototype.init =
function() {

	this._simpleAppName = this.createApp("Tetris", "", "Play Tetris in Zimbra!");

};

/**
 * This method gets called by the Zimlet framework each time the application is opened or closed.
 *  
 * @param	{String}	appName		the application name
 * @param	{Boolean}	active		if true, the application status is open; otherwise, false
 */
com_tetris_HandlerObject.prototype.appActive =
function(appName, active) {
	
	switch (appName) {
		case this._simpleAppName: {
		
			var app = appCtxt.getApp(appName); // get access to ZmZimletApp

			break;
		}
	}
	
	// do something
};

/**
 * This method gets called by the Zimlet framework when the application is opened for the first time.
 *  
 * @param	{String}	appName		the application name		
 */
com_tetris_HandlerObject.prototype.appLaunch =
function(appName) {

	switch (appName) {
		case this._simpleAppName: {
			// do something
		
			var app = appCtxt.getApp(appName); // get access to ZmZimletApp

app.setContent('<br><br>&nbsp;&nbsp;&nbsp;&nbsp;Click to Play!');

var toolbar = app.getToolbar(); // returns ZmToolBar
   toolbar.setContent("<button style='margin:10px;' onclick='com_tetris_HandlerObject.prototype._launchApp()'>Click to Play!</button><button style='margin:10px;' onclick='com_tetris_HandlerObject.prototype._resetApp()'>Game Over!</button><br><br>");
			break;
		}
	}

};

/* This method destroys the Zimlet tab
 */
com_tetris_HandlerObject.prototype._resetApp=
function(appName) {
	app = appCtxt.getCurrentApp();
   app.setContent('');
	app.reset(false) ;
	appCtxt.getAppController().activateApp("Mail") ;	
} 

com_tetris_HandlerObject.prototype._launchApp=
function(appName) {
	app = appCtxt.getCurrentApp();
   app.setContent('<iframe style="width:95%; height:95%; border:5px;" src="/service/zimlet/com_tetris/index.html">');
}
